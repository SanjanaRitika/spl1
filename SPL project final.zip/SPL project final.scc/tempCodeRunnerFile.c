void sortalphabetically()
{

	item product[100]; 
	
	FILE *fp=fopen("records.bin","rb");
	FILE *counter=fopen("counter.dat","r");
	
	int count;
	fscanf(counter,"%d",&count);
	
	fread(&product, sizeof(product), 1, fp);

	mergeSort(product, 0, count - 1, 0);

	printf("\n -----------------------------------------------------------------------------------------------------------");
	printf("\n|   Product no   |   Product Name   |   Stock   |    Price   |    Mfg date   |    Exp date    |     Type    |" );
	printf("\n -----------------------------------------------------------------------------------------------------------");
	
	for(int i=0;i<count;i++)
	{
		printf("\n|   %10d   |   ",product[i].prodno);
		printf("%12s   |   ",product[i].prodname);
		printf("%5d   |   ",product[i].qty);
		printf("%.2f    |   ",product[i].price);
		printf("%2d/%2d/%2d  |   ",product[i].mfg.day,product[i].mfg.month,product[i].mfg.year);
		printf("%2d/%2d/%2d   |   ",product[i].exp.day,product[i].exp.month,product[i].exp.year);
		printf("%5s     |",product[i].type);
	}
	printf("\n -----------------------------------------------------------------------------------------------------------");
	
	fclose(fp);
	
	char ch;
	printf("\n\nWould you like to go back to the menu? [Y/N]\n");
	getchar();
	scanf("%c",&ch);
	
	if(ch=='Y'||ch=='y')
	{
		clrscr();
		menu();
	}
	
	else 
	{
		exit(0);
	}
	
}